#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "codeeditor.h"
#include <QTextStream>
#define itos(x) QString::number(x)


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow){

    ui->setupUi(this);

    QFont font;
    font.setFamily("Courier");
    font.setFixedPitch(true);
    font.setPointSize(12);

    field = new CodeEditor(ui->openGLWidget);
    field->setFont(font);

    logger = new CodeEditor(ui->openGLWidget_2);

    out = new QPlainTextEdit(ui->openGLWidget_3);

    highlighter = new Highlighter(field->document());
    highlighter->setParent(this);

    QFile inputFile("temp.txt");

    QString text;
    if (inputFile.open(QIODevice::ReadOnly)){
       QTextStream in(&inputFile);

       text = in.readAll();

       inputFile.close();
    }

    field->appendPlainText(text);
}

/*
    Код для добавления новых правил подстветки
    HighlightingRule rule;

    rule.pattern = QRegExp("101");

    QTextCharFormat format;

    format.setFontItalic(false);
    format.setForeground(Qt::red);

    rule.format = format;

    highlighter->highlightingRules.append(rule);
*/

void MainWindow::saveText(){
    QFile outputFile("temp.txt");

    if (outputFile.open(QIODevice::WriteOnly)){
       QTextStream out(&outputFile);

       out << field->toPlainText();

       outputFile.close();
    }
}

MainWindow::~MainWindow(){
    saveText();

    delete ui;
}

void MainWindow::on_pushButton_clicked(){
    out->clear();
    out->appendPlainText(highlighter->toString());
}
