/****************************************************************************
**
** Copyright (C) 2015 The Qt Company Ltd.
** Contact: http://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "highlighter.h"
#include <QMap>

#define itos(x) QString::number(x)

Highlighter::Highlighter(QTextDocument *parent)
    : QSyntaxHighlighter(parent){
    HighlightingRule rule;

    connect(document(), SIGNAL(blockCountChanged(int)), this, SLOT(clearTokens()));

    adressFormat.setForeground(Qt::darkBlue);
    adressFormat.setFontWeight(QFont::Bold);
    rule.pattern = QRegExp("\\b(\\d|[A-F])(\\d|[A-F])(\\d|[A-F])(\\d|[A-F])\\b");
    rule.format = adressFormat;
    rule.type = TokenType::ADRESS;
    highlightingRules.append(rule);

    wordFormat.setFontWeight(QFont::Bold);
    wordFormat.setForeground(Qt::darkMagenta);
    rule.pattern = QRegExp("\\b[A-Za-z]+\\b");
    rule.format = wordFormat;
    rule.type = TokenType::WORD;
    highlightingRules.append(rule);

    operationFormat.setFontWeight(QFont::Bold);
    operationFormat.setForeground(Qt::darkYellow);
    rule.pattern = QRegExp("\\b\\d\\d\\b");
    rule.format = operationFormat;
    rule.type = TokenType::OPERATION;
    highlightingRules.append(rule);

    registrFormat.setFontWeight(QFont::Bold);
    registrFormat.setForeground(Qt::green);
    rule.pattern = QRegExp("\\b(\\d|[A-F])\\b");
    rule.format = registrFormat;
    rule.type = TokenType::REGISTR;
    highlightingRules.append(rule);

    multiLineCommentFormat.setForeground(Qt::gray);

    commentStartExpression = QRegExp("/\\*");
    commentEndExpression = QRegExp("\\*/");
    commentOneExpression = QRegExp("//[^\n]*");
}

void Highlighter::setParent(MainWindow * _parent){
    parent = _parent;
}

QString Highlighter::toString(TokenType value){
    switch (value) {
    case WORD:
        return QString("WORD");
        break;
    case NUMBER:
        return QString("NUMBER");
        break;
    case ADRESS:
        return QString("ADRESS");
        break;
    case OPERATION:
        return QString("OPERATION");
        break;
    case REGISTR:
        return QString("REGISTR");
        break;
    default:
        break;
    }
}

QString Highlighter::toString(){
    QString str = "";
    foreach (auto m, Tokens) {
        foreach (Token t, m) {
            str += Highlighter::toString(t.type) + " " + t.text + " ";
        }
        str += '\n';
    }
    return str;
}

void Highlighter::highlightBlock(const QString &text){

    int lineIndex = this->currentBlock().blockNumber();

    Tokens.erase(Tokens.find(lineIndex));
    setCurrentBlockState(0);

    int startIndex = 0;
    if (previousBlockState() != 1)
        startIndex = commentStartExpression.indexIn(text);

    while (startIndex >= 0) {
        int endIndex = commentEndExpression.indexIn(text, startIndex);
        int commentLength;
        if (endIndex == -1) {
            setCurrentBlockState(1);
            commentLength = text.length() - startIndex;
        } else {
            commentLength = endIndex - startIndex
                            + commentEndExpression.matchedLength();
        }
        setFormat(startIndex, commentLength, multiLineCommentFormat);
        startIndex = commentStartExpression.indexIn(text, startIndex + commentLength);
    }

    if (previousBlockState() != 1)
        startIndex = commentOneExpression.indexIn(text);
    if(startIndex != -1){
        int length = text.size() - startIndex;
        setFormat(startIndex, length, multiLineCommentFormat);
    }

    setCurrentBlockState(0);

    foreach (const HighlightingRule &rule, highlightingRules) {
        QRegExp expression(rule.pattern);
        int index = expression.indexIn(text);
        while (index >= 0) {
            int length = expression.matchedLength();
            if(format(index) != multiLineCommentFormat){
                Token temp;
                temp.type = rule.type;
                temp.text = text.mid(index, length);
                Tokens[lineIndex].insert(index, temp);
                setFormat(index, length, rule.format);
            }
            index = expression.indexIn(text, index + length);
        }
    }
}

void Highlighter::clearTokens(){
    Tokens.clear();
    this->rehighlight();
    parent->out->clear();
    parent->out->appendPlainText(toString());
}
