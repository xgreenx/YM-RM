#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "codeeditor.h"
#include <QMainWindow>
#include "highlighter.h"

namespace Ui {
class MainWindow;
}

class Highlighter;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    CodeEditor* field, *logger;
    QPlainTextEdit* out;
    explicit MainWindow(QWidget *parent = 0);
    void saveText();
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    Highlighter *highlighter;
};

#endif // MAINWINDOW_H
